
Dental - v1 Dental
==============================

This dataset was exported via roboflow.ai on July 17, 2021 at 12:20 PM GMT

It includes 663 images.
Root-canal-treatmment-caries-res are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


